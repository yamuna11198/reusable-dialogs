// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { shareReplay } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class TestService {

//   constructor(private httpclient:HttpClient) { }
//   getSector(){
//     return this.httpclient.get(`/assets/sector.json`).pipe(shareReplay());
//   }
// }
